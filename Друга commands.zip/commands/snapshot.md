# /snapshot — Create a PHOENIX source snapshot

Creates a timestamped backup of all production source code to
`/Users/macos/Documents/PHOENIXDSP/PHX_Backups/`.

## Usage
`/snapshot <slug>`

**slug** — short kebab-case description:
- `before-<what-changes>` — before a risky operation
- `<what-done>-stable` — after a successful session
- `milestone-<name>` — significant milestone

## Instructions

Arguments: $ARGUMENTS

```bash
PHOENIX_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo '/Users/macos/Documents/PHOENIXDSP/PHOENIX')"
```

### Step 1 — Validate slug
If $ARGUMENTS is empty, ask the user: "Snapshot slug? (e.g. `before-cmake-refactor`)"

### Step 2 — Run snapshot script
```bash
cd "$PHOENIX_ROOT"
./tools/snapshot.sh $ARGUMENTS
```

### Step 3 — Report result
Show the user:
- Full path of created snapshot
- Size
- Remind them to fill in `SNAPSHOT.md` if notable context is needed

### Step 4 — Continue with the original task
The snapshot is a safety net. After confirming it succeeded, proceed with whatever
risky operation was planned.
