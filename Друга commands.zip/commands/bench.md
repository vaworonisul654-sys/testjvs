# /bench — Run Phoenix DSP benchmarks

## Usage
`/bench [target] [file]`

**Targets:**
- `purity [wavfile]` — correlation purity test on specific WAV file
- `batch` — full batch purity on all test audio files
- `cpu` — CPU benchmark: BioEngine throughput @ 512 samples
- `q-sweep` — Q factor sweep to find optimal value (q_purity_sweep.cpp)
- `investor` — InvestorBench: production-grade full pipeline benchmark
- (blank) — runs `batch` + `cpu`

## Instructions

Arguments: $ARGUMENTS

Parse target and optional filename from $ARGUMENTS.

### `purity [wavfile]`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX "
python3 phoenix_370_purity_test.py [wavfile]
```
Report: correlation %, SDR, any artifacts.

### `batch`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX "
python3 phoenix_370_batch_test.py
```
Report table: file → correlation. Flag anything below **98%** as REGRESSION.
Baselines:
- Average target: ≥ 98.05%
- Peak target: ≥ 99.90%

### `cpu`
Build and run `Phoenix_CPP/tests/BioEngineBench.cpp` or `ChainBenchmark.cpp`:
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /Phoenix_CPP"
make BioEngineBench
./BioEngineBench
```
Report: throughput (samples/sec), CPU%, latency in samples.
Target: ≤ 5% CPU @ 512 samples, 48kHz.

### `q-sweep`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /Phoenix_CPP"
make q_purity_sweep
./q_purity_sweep
```
Plot/table: Q value → correlation. Mark Q=21.6 position.

### `investor`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /Phoenix_CPP"
make InvestorBench
./InvestorBench
```
This is the production showcase benchmark. Report all metrics.

### After any benchmark
If results REGRESS from baselines → flag immediately and do NOT update docs.
If results IMPROVE → note the delta and ask if QUICK_REFERENCE.md should be updated.
