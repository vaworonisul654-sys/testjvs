# /save — Session end protocol

Saves session state per PHOENIX Agent Handoff Protocol.

## Usage
`/save [notes]`

Optional notes = brief summary of what was done this session.

## Instructions

Arguments: $ARGUMENTS

### Step 1 — Determine what changed this session

Reflect on the conversation: what was built, tested, fixed, decided, or designed?

### Step 2 — Update CURRENT_FOCUS.md

File: `/Users/myai/Documents/AI_Projects/PHOENIX /docs/CURRENT_FOCUS.md`

Update sections:
- **Сейчас в работе** → what's mid-flight (not done yet)
- **Следующее в очереди** → what's clearly next
- **Заблокировано** → anything with unresolved dependencies
- **Недавно завершено** → prepend new entry with date `(YYYY-MM-DD)`

Keep it concise. Max 5 bullet points per section.

### Step 3 — Update DECISIONS.md (if any architectural decision was made)

File: `/Users/myai/Documents/AI_Projects/PHOENIX /docs/DECISIONS.md`

Only if this session involved a real architectural choice (new pattern, rejected approach, constant change, API design). Append:

```markdown
## [YYYY-MM-DD] — <decision title>
**Context:** <why decision was needed>
**Decision:** <what was decided>
**Rationale:** <why this approach over alternatives>
**Impact:** <what files/modules are affected>
```

Do NOT add trivial entries (bug fixes, routine builds).

### Step 4 — Archive snapshot if significant work was done

If new source files were created or significantly modified:
```bash
TIMESTAMP=$(date +%Y-%m-%d_%H%M%S)
mkdir -p "/Users/myai/Documents/AI_Projects/PHOENIX /PhoenixPluginFramework/.archive/snapshot_$TIMESTAMP"
# Copy only modified files, not build artifacts
```

Ask user before archiving if scope is unclear.

### Step 5 — Confirm in one line

Output exactly:
```
✅ Saved — [YYYY-MM-DD HH:MM] | Focus updated | <N> decisions logged | <archive: yes/no>
```
