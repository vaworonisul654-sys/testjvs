# /new-module — Scaffold a new Phoenix DSP module

Creates a production-ready DSP module in Phoenix_CPP and registers it for codegen.

## Usage
`/new-module <ModuleName> [description]`

Example: `/new-module SpectralFrost "Freeze + shimmer reverb"`

## Instructions

Arguments: $ARGUMENTS

Parse: first word = ModuleName (PascalCase), rest = description.

### Step 1 — Clarify before coding

Ask the user:
1. **Processing domain**: per-band spectral (SpectralBlock) or time-domain?
2. **Key parameters**: names, ranges, defaults (3-5 params typical)
3. **BioEngine pattern**:
   - `spectral_block` — impl_.process(SpectralBlock&) — most common
   - `spectral_gravity` — computeGravityFlow + tick + processAll
   - `shepard_riser` — tick(sigsL) + copy L→R
4. **Spectral Mirror**: enabled (standard) or disabled (freeze/denoiser — pure IIR output)?
5. **Init style**:
   - `prepare_contract` — prepare(sr, maxBS, numBands, arena)
   - `init_numBands_sr` — init(numBands, sr)

Wait for answers, then proceed.

### Step 2 — Create DSP header `Phoenix_CPP/include/phx/modules/<ModuleName>.hpp`

Rules:
- NO FFT. IIR or per-band spectral manipulation only.
- Float32 everywhere. No doubles.
- No heap allocation after prepare().
- SIMD-friendly: operate on block.sigsL/sigsR (float* arrays, length = simdPaddedBands = 372).
- Params struct must be a nested struct: `struct Params { ... };`

```cpp
#pragma once
// <ModuleName>.hpp — <description>
// Phoenix DSP — BioCell Architecture

#include <phx/core/Common.hpp>
#include <phx/core/ModuleContract.hpp>

namespace phx {

class <ModuleName> {
public:
    struct Params {
        float param1 = 0.5f;  // [0.0, 1.0] description
    };

    void prepare(float sampleRate, int maxBlockSize, int numBands, ModuleArena& arena);
    void setParams(const Params& p) noexcept;
    void process(SpectralBlock& block) noexcept;
    void reset() noexcept;

private:
    float sr_ = 44100.f;
    // Internal state — no heap alloc after prepare()
};

} // namespace phx
```

### Step 3 — Register in `Phoenix_CPP/registry/modules.yaml`

Add a new entry under `# GENERATED — use phoenix_codegen.py` section:

```yaml
  - id: <snake_name>
    class: <ModuleName>
    params_struct: <ModuleName>::Params
    display_name: "<Display Name>"
    header_file: "phx/modules/<ModuleName>.hpp"
    category: <saturation|dynamics|reverb|pitch|spectral|utility>
    description: "<one line description>"
    plugin_id: "phx.<snake_name>"
    status: pending
    init_style: prepare_contract          # or init_numBands_sr
    process_type: spectral_block          # or spectral_gravity, shepard_riser
    use_mirror: true                      # false for freeze/denoiser
    sidechain: false
    params:
      - name: param1
        display: "Param 1"
        type: float
        min: 0.0
        max: 1.0
        default: 0.5
        unit: ""
        ramp: 32
        automation: true
        formatter: generic
      # Mix is auto-added by codegen — do NOT add it manually
```

### Step 4 — Create test `Phoenix_CPP/tests/test_<snake_name>.cpp`

```cpp
// test_<snake_name>.cpp — Unit test for <ModuleName>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <phx/core/BioEngine.hpp>
#include <phx/modules/<ModuleName>.hpp>

int main() {
    // Setup
    phx::BioEngine engine;
    phx::Config cfg;
    cfg.numBands = phx::NUM_BANDS;
    cfg.sampleRate = 48000.f;
    engine.init(cfg);
    engine.prepareToPlay(48000.f, 512);

    phx::SpectralBlock block;
    block.sigsL    = engine.getSignalsL().data();
    block.sigsR    = engine.getSignalsR().data();
    block.envs     = engine.getEnvelopes().data();
    block.numBands = phx::NUM_BANDS;

    phx::ModuleArena arena{};
    phx::<ModuleName> m;
    m.prepare(48000.f, 512, phx::NUM_BANDS, arena);

    // Test: silence in → finite output
    phx::<ModuleName>::Params p;
    m.setParams(p);
    float sample = 0.f;
    float baseSumL = 0.f, baseSumR = 0.f;
    engine.analyzeFrame(sample, sample, baseSumL, baseSumR);
    m.process(block);
    float outL = 0.f, outR = 0.f;
    engine.synthesizeFrame(outL, outR);
    assert(std::isfinite(outL));
    assert(std::isfinite(outR));

    printf("[PASS] <ModuleName>: silence → finite output\n");

    // TODO: add module-specific behavioral tests here

    printf("[PASS] <ModuleName> all tests\n");
    return 0;
}
```

### Step 5 — Generate the plugin

```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /PhoenixPluginFramework"
python tools/phoenix_codegen.py <ModuleName>
```

### Step 6 — Build & verify

```bash
cmake --build build_qa -j$(sysctl -n hw.logicalcpu)
./build_qa/framework_qa
```

### Step 7 — Report

Show:
- Files created (DSP .hpp + modules.yaml entry + 6 codegen outputs)
- Parameters designed (table: name | range | default | meaning)
- Test result
- Architecture choices made (init_style, process_type, use_mirror)
