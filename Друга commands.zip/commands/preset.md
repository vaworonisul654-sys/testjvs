# /preset — Generate and inject factory presets for a Phoenix plugin

Generate AI-driven factory presets for any Phoenix plugin using Claude API,
write YAML source files, and inject the preset bar into the plugin HTML.

## Usage

`/preset <PluginName> [--count N] [--inject-only]`

**Examples:**
- `/preset MetaSaturator` — generate 12 presets + inject into HTML
- `/preset MetaSaturator --count 8` — generate 8 presets
- `/preset SoulTransfer --inject-only` — inject existing YAMLs into HTML (no API call)

## Arguments

`$ARGUMENTS`

Parse:
- `PluginName` — first word, PascalCase plugin name
- `--count N` — number of presets to generate (default: 12)
- `--inject-only` — skip Claude API, just inject existing YAMLs into HTML

---

## Protocol

### Step 0 — Validate

Check `plugins/<PluginName>/` directory exists:
```bash
ls "plugins/<PluginName>/"
```

Check `plugins/<PluginName>/plugin.phx.yaml` exists:
```bash
ls "plugins/<PluginName>/plugin.phx.yaml"
```

If either missing — stop:
> Plugin '<Name>' or its plugin.phx.yaml not found.
> Run `/new-plugin <Name>` first, or check spelling.

Check Python dependency:
```bash
python3 -c "import anthropic, yaml; print('OK')"
```

If fails — tell user:
> Missing dependencies. Run: `pip install anthropic pyyaml`

For `--inject-only`: check that `plugins/<PluginName>/presets/` has at least one `.yaml` file.
If no YAML files found — stop:
> No preset YAML files found. Run `/preset <Name>` without `--inject-only` to generate them first.

### Step 1 — Run preset_gen.py

```bash
PHOENIX_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo '/Users/macos/Documents/PHOENIXDSP/PHOENIX')"
cd "$PHOENIX_ROOT"
```

For normal generation:
```bash
python3 framework/tools/preset_gen.py <PluginName> --count <N> --inject
```

For `--inject-only`:
```bash
python3 framework/tools/preset_gen.py <PluginName> --inject-only
```

If the script exits with non-zero status — show the full output and stop.

### Step 2 — Verify output

Check YAML files were created:
```bash
ls "plugins/<PluginName>/presets/"
```

Check HTML was updated (look for PHX_PRESETS_BEGIN marker):
```bash
grep -l "PHX_PRESETS_BEGIN" "plugins/<PluginName>/ui/"*.html
```

If HTML was NOT updated (no marker found), it means the plugin HTML doesn't have
the preset bar yet. In that case:

**Add the preset bar manually** by editing the plugin's primary HTML file
(`*-ember.html` > `*.html` > `index.html`):

1. Add CSS (copy `.preset-bar`, `.preset-sel`, `.preset-cat`, `.preset-desc` from MetaSaturator ember)
2. Reduce `.main` height by 22px (update the comment too)
3. Add HTML block between mode tabs and main:
   ```html
   <div class="preset-bar">
     <span class="preset-lbl">PRESET</span>
     <select class="preset-sel" id="presetSel"
             onchange="onPresetChange(parseInt(this.value))"></select>
     <span class="preset-cat" id="pCat">Default</span>
     <span class="preset-desc" id="pDesc">Default settings</span>
   </div>
   ```
4. Add JS before init:
   ```javascript
   // PHX_PRESETS_BEGIN
   const PHX_PRESETS = [];  // will be injected by preset_gen.py
   // PHX_PRESETS_END

   function buildPresets() {
     const sel = document.getElementById('presetSel');
     PHX_PRESETS.forEach((p, i) => {
       const o = document.createElement('option');
       o.value = i; o.textContent = p.name;
       sel.appendChild(o);
     });
   }

   function onPresetChange(idx) {
     const p = PHX_PRESETS[idx];
     if (!p) return;
     document.getElementById('pCat').textContent  = p.category;
     document.getElementById('pDesc').textContent = p.description;
     window.phx.loadPreset(p.params);
     // Sync local UI state (adapt param IDs to this plugin):
     Object.entries(p.params).forEach(([k, v]) => {
       const id = parseInt(k, 10);
       if (typeof pval !== 'undefined') pval[id] = v;
       if (id === P_MODE && typeof setMode === 'function') { setMode(Math.round(v), false); return; }
       if (typeof redrawKnob === 'function') redrawKnob(id);
     });
   }
   ```
5. Call `buildPresets()` inside init / requestAnimationFrame
6. Re-run: `python3 framework/tools/preset_gen.py <PluginName> --inject-only`

### Step 3 — Quick sanity check

Count presets in HTML:
```bash
python3 -c "
import re
html = open('plugins/<PluginName>/ui/<primary_html_file>').read()
start = html.index('// PHX_PRESETS_BEGIN')
end   = html.index('// PHX_PRESETS_END')
n = html[start:end].count(\"{ name: '\")
print(f'Presets injected: {n}')
"
```

### Step 4 — Report

Show:
```
✅ Preset System — <PluginName>

YAML files: plugins/<Name>/presets/ (N files)
  00_init.yaml
  01_gentle_warmth.yaml
  ...

HTML updated: plugins/<Name>/ui/<file>.html
  PHX_PRESETS: N presets injected

Categories: <list unique categories>

Next: open HTML in browser to verify preset dropdown works (0 console errors).
```

---

## Reference

- Preset YAML format + architecture: `docs/architecture/PRESET_SYSTEM.md`
- Generator source: `framework/tools/preset_gen.py`
- Bridge API: `web-ui/phoenix-ui/phx-bridge.js` — `loadPreset(params)`
- Example: `plugins/MetaSaturator/presets/` (13 presets)
- Decision: DEC-070
