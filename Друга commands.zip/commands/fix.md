# /fix — Agent Bug Fix Protocol

You are a Phoenix DSP bug-fix agent. Fix a **batch** of tasks from the work queue, then stop.

**Language:** respond in Russian. Code, comments, variable names, commit messages — English only.

> ⚠️ CLAUDE.md has a startup ritual ("Прочитал. Сейчас в работе..."). **Ignore it for this session.**
> Your startup protocol is this file. Follow the steps below in order.

---

## Batch size rules

| Severity | Tasks per agent | Reason |
|----------|----------------|--------|
| **CRITICAL** | 1 | Maximum blast radius, needs full focus |
| **HIGH**     | 1 | Significant logic/race/RT risk |
| **MEDIUM**   | 1–3 | Moderate risk, related files |
| **LOW**      | 5–10 | One-liners, mechanical fixes, safe to batch |

Always process tasks **in priority order**: CRITICAL → HIGH → MEDIUM → LOW.
Never mix severities in one batch (e.g. don't fix 1 HIGH + 3 LOW in one run).

---

## Step 1 — Read project rules

Read before touching anything:
```
/Users/macos/Documents/PHOENIXDSP/PHOENIX/framework/CRITICAL_RULES.md
```

Key rules:
- No `new`/`delete`/`malloc`/`push_back`/`resize` in `onProcess()` (audio thread)
- Sacred constants — never modify: `NUM_BANDS=370`, `Q_GOLDEN=21.6`, `GOLDEN_HUMILITY=0.3804`
- All builds go into `framework/build/` only

---

## Step 2 — Claim a batch

Read the work queue:
```
/Users/macos/Documents/PHOENIXDSP/PHOENIX/Worktodo.md
```

1. Find the **highest-priority OPEN task** to determine severity tier (CRITICAL > HIGH > MEDIUM > LOW)
2. Collect tasks from that tier only, up to the batch size limit:
   - CRITICAL or HIGH → take **1** task
   - MEDIUM → take up to **3** tasks (prefer related files / same module)
   - LOW → take up to **10** tasks (prefer same file or same category)
3. **Immediately** edit each claimed task: `OPEN` → `IN_PROGRESS`
   Do this as your very next action — before reading any source files.

---

## Step 2b — Verify claim (anti-duplication)

Re-read `Worktodo.md` and verify every claimed task shows `IN_PROGRESS`.

- If a task reverted to `OPEN` → another agent grabbed it. Skip it, pick a different one.
- If every OPEN task is already `IN_PROGRESS` → **stop**. Report: "All tasks claimed."

---

## Step 3 — Understand the code

For each claimed task, read:
1. The file listed in the task (at the line number given)
2. Any other file mentioned in the FIX description

For LOW batches: read all files in the batch before starting fixes — one pass is enough.

---

## Step 4 — Fix the batch

Apply fixes **one task at a time**, in order. For each:

**Rules:**
- **Minimal change** — fix only what the task says. No cleanup, no refactoring around it.
- **No allocation in audio thread** — if fix requires `new`/`push_back`/`resize` inside `onProcess()`, mark `WONTFIX`.
- **Sacred constants are immutable** — `NUM_BANDS`, `Q_GOLDEN`, `GOLDEN_HUMILITY`.

**What counts as risky → mark WONTFIX, don't apply:**
- Changing `CMakeLists.txt`
- Deleting or renaming files
- Modifying `core/src/BioEngine.cpp` hot path
- Changing function signatures called from multiple plugins
- Touching more than 3 files for a single task

**LOW batch strategy:** for mechanical fixes (PI literals, M_PI→std::numbers::pi, unused includes,
dead variables, sacred constant literals) — apply all in a single editing pass per file.
Group by file: fix everything in FileA, then FileB, etc. Don't jump between files.

---

## Step 5 — Verify

Check if QA binary exists:
```bash
ls /Users/macos/Documents/PHOENIXDSP/PHOENIX/framework/build/qa/framework_qa
```

If it **does not exist** — build first:
```bash
cmake -S /Users/macos/Documents/PHOENIXDSP/PHOENIX/framework \
      --preset qa \
      -B /Users/macos/Documents/PHOENIXDSP/PHOENIX/framework/build/qa
```

Then run:
```bash
cmake --build /Users/macos/Documents/PHOENIXDSP/PHOENIX/framework/build/qa \
      -j$(sysctl -n hw.logicalcpu) 2>&1 | tail -5
/Users/macos/Documents/PHOENIXDSP/PHOENIX/framework/build/qa/framework_qa 2>&1 | tail -3
```

**Expected:** `Passed: 218   Failed: 0`

If tests fail:
- Revert **all** changes in the batch
- Set all claimed tasks back to `OPEN`
- Bisect: try fixing tasks one by one to find which one broke tests
- Report the failure

---

## Step 6 — Update Worktodo.md

For each task in the batch:
- `IN_PROGRESS` → `FIXED` (fix applied, tests pass)
- `IN_PROGRESS` → `OPEN` (reverted, tests failed)
- `IN_PROGRESS` → `WONTFIX` (risky — add a one-line note explaining why)

---

## Step 7 — Append to todoreport.md

Read first, then write. Never overwrite without reading.

File:
```
/Users/macos/Documents/PHOENIXDSP/PHOENIX/todoreport.md
```

One block per **batch** (not per task):

```markdown
---
## Batch [BUG-XXX .. BUG-YYY] — N tasks — SEVERITY
**Status:** N FIXED, N WONTFIX, N REVERTED
**Tests:** 218/218 PASS

### Fixes applied
- [BUG-XXX] File.hpp:N — что поправлено (одна строка)
- [BUG-YYY] File.hpp:N — что поправлено
- ...

### WONTFIX / Reverted
- [BUG-ZZZ] — причина (одна строка)

### Заметки
Любые follow-up риски или интересные находки.
```

---

## Step 8 — Stop

Batch done. Stop here.
- Do **not** pick another batch
- Do **not** commit (main session handles git)
- Do **not** push anything

---

## Quick reference

| Что | Где |
|-----|-----|
| Очередь задач | `Worktodo.md` (корень проекта) |
| Репорт | `todoreport.md` (корень проекта) |
| QA бинарь | `framework/build/qa/framework_qa` |
| Sacred constants | `core/include/phx/core/Common.hpp` |
| DSP источники | `core/src/`, `core/include/phx/` |
| Framework | `framework/include/phx/` |
| Правила фреймворка | `framework/CRITICAL_RULES.md` |
