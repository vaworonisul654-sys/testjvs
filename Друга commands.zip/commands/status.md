# /status — Show current PHOENIX project state

Quick situational awareness. Read, don't modify.

## Usage
`/status`

## Instructions

No arguments needed: $ARGUMENTS

### Step 1 — Read state files (in order)

1. `/Users/myai/Documents/AI_Projects/PHOENIX /docs/CURRENT_FOCUS.md`
2. `/Users/myai/Documents/AI_Projects/PHOENIX /docs/DECISIONS.md` — last 10 entries only
3. `/Users/myai/Documents/AI_Projects/PHOENIX /PhoenixPluginFramework/PLUGIN_REGISTRY.md`
4. Check if `PhoenixPluginFramework/.build/` exists → has it been built recently?
5. Check if any `checkpoints/` exist in PHOENIX_CODEC_2.0

### Step 2 — Check git-like state

Look for any `.archive/` entries newer than 7 days:
```bash
find "/Users/myai/Documents/AI_Projects/PHOENIX " -path "*/.archive/*" -newer "/Users/myai/Documents/AI_Projects/PHOENIX /docs/CURRENT_FOCUS.md" -maxdepth 4
```

### Step 3 — Quick metrics snapshot

Report last known values (from docs, not rerun benchmarks):
- Framework tests: last known pass count
- Phoenix_CPP: Average correlation, Peak correlation
- Sacred Constants: verified date
- Codec: current version

### Step 4 — Output format

```
═══════════════════════════════════════
PHOENIX DSP — Status Report
═══════════════════════════════════════
📌 Current Focus: <from CURRENT_FOCUS.md>
🔜 Next: <from CURRENT_FOCUS.md>
🚫 Blocked: <from CURRENT_FOCUS.md>

📦 Framework:    v1.0.0  | Tests: 146/146 ✅ (last: YYYY-MM-DD)
🧬 Phoenix_CPP: 370 bands | Corr avg 98.05% | Peak 99.90% ✅
🔊 Codec:        v2.24.0 | ~1000 bps | 1-sample latency ✅

🔧 Plugins registered: Gain, SidechainBlend, SpectralLattice, NuGate
    + any unreleased/experimental

📋 Recent decisions (last 3):
<from DECISIONS.md>

❓ Recommended next action: <infer from focus and blocked>
═══════════════════════════════════════
```
