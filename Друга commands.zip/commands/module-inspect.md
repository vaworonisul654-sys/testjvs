# /module-inspect — Deep dive into any Phoenix DSP module

Reads source, tests, docs, and reports full picture of a module.

## Usage
`/module-inspect <ModuleName>`

Examples:
- `/module-inspect SpectralLattice`
- `/module-inspect LangevinSaturator`
- `/module-inspect BioEngine`

## Instructions

Arguments: $ARGUMENTS

ModuleName = $ARGUMENTS (strip whitespace).

### Step 1 — Locate files

Search in:
- `Phoenix_CPP/include/phx/modules/<ModuleName>.hpp`
- `Phoenix_CPP/include/phx/core/<ModuleName>.hpp`
- `Phoenix_CPP/include/phx/dsp/<ModuleName>.hpp`
- `Phoenix_CPP/src/<ModuleName>.cpp`
- `Phoenix_CPP/tests/test_<snake_name>.cpp`
- `Phoenix_CPP/tests/<ModuleName>*.cpp`
- `PhoenixPluginFramework/plugins/<ModuleName>/`

Read all found files.

### Step 2 — Extract and report

**Interface:**
- Public API (methods, structs, params)
- Parameter ranges and defaults
- Input/output: what does `process()` expect and return?

**Algorithm:**
- Core DSP logic in plain language (no paraphrasing of the math — show exact formulas)
- Which Sacred Constants does it use?
- SIMD paths: where and how?

**Tests:**
- What does the test bench verify?
- Pass/fail status (from last audit in CLAUDE.md or run if needed)

**Known issues or TODOs:**
- Comments marked `// TODO`, `// FIXME`, `// HACK`
- Any warnings from last build

**Integration:**
- Is it used in any plugin? (grep `PhoenixPluginFramework/plugins/`)
- Is it part of BioAmp chain or standalone?

### Step 3 — Output format

```
══════════════════════════════════════════
MODULE: <ModuleName>
══════════════════════════════════════════
Location:   include/phx/modules/<Name>.hpp
Status:     [STABLE / EXPERIMENTAL / RESEARCH]

INTERFACE
─────────
<public API summary>

ALGORITHM
─────────
<core math/DSP logic>
Sacred Constants used: <list>
SIMD: <yes/no, where>

TESTS
─────
<test file> → <what's tested> → <PASS/FAIL>

INTEGRATION
───────────
Used in plugins: <list>
Used in chains:  <list>

ISSUES
──────
<TODOs, warnings, known limitations>
══════════════════════════════════════════
```
