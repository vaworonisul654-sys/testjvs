# /codec — PHOENIX_CODEC_2.0 operations

Encode, decode, validate, and audit the bio-inspired audio codec.

## Usage
`/codec [action] [args]`

**Actions:**
- `encode <wavfile>` — encode WAV to .PHX
- `decode <phxfile>` — decode .PHX to WAV
- `validate <wavfile>` — encode→decode roundtrip + MOS estimate
- `audit` — integrity check of DECODERFULL scripts
- `diff <original.wav> <decoded.wav>` — spectral diff + correlation
- (blank) — show codec status (version, bitrate, latency)

## Instructions

Arguments: $ARGUMENTS

Parse action and filenames from $ARGUMENTS.

Base path: `/Users/myai/Documents/AI_Projects/PHOENIX /PHOENIX_CODEC_2.0/`

### `encode <wavfile>`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /PHOENIX_CODEC_2.0/DECODERFULL"
python3 scripts/encode.py <wavfile>
```
Report: output .PHX path, file size, effective bitrate.

### `decode <phxfile>`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /PHOENIX_CODEC_2.0/DECODERFULL"
python3 scripts/decode.py <phxfile>
```
Report: output WAV path.

### `validate <wavfile>`
Run full roundtrip:
1. encode → .PHX
2. decode → .WAV
3. Compare original vs decoded:
   - Correlation
   - Max diff
   - Estimated MOS (if script available)

Target: MOS ≥ 4.0 for speech.

### `audit`
List all scripts in DECODERFULL/scripts/:
```bash
ls "/Users/myai/Documents/AI_Projects/PHOENIX /PHOENIX_CODEC_2.0/DECODERFULL/scripts/"
```
Read each script header comment. Verify:
- Bark-scale 120 bands intact
- Bio-Spark weighting: `(f/1000)^0.7` present
- No FFT (IIR only)
- No external dependencies beyond numpy/scipy/soundfile

### `diff <original> <decoded>`
```bash
python3 -c "
import soundfile as sf, numpy as np
orig, sr = sf.read('<original>')
dec, _  = sf.read('<decoded>')
n = min(len(orig), len(dec))
corr = np.corrcoef(orig[:n], dec[:n])[0,1]
maxdiff = np.max(np.abs(orig[:n]-dec[:n]))
print(f'Correlation: {corr:.4f}')
print(f'Max diff:    {maxdiff:.6f}')
"
```

### Blank / status
Read `07_DOCUMENTATION/MANIFESTO.md` version header.
Report: version, bitrate, latency, MOS from last benchmark.

### PROTOCOL REMINDER
Archive First. Never delete files in CODEC_2.0. If refactoring: copy to new path, keep old.
New files go to `09_OUTPUT_RESULTS/` (audio) or `03_PYTHON_EXPERIMENTS/` (scripts).
