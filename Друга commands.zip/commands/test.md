# /test — Run Phoenix DSP test suites

## Usage
`/test [suite]`

**Suites:**
- `framework` — ctest in PhoenixPluginFramework (146 tests)
- `cpp` — make test in Phoenix_CPP
- `audit` — core 10 tests: BioEngine, PRFB, Langevin, SpectralLattice, ShepardRiser, SpectralNebula, SpectralLightning
- `constants` — verify Sacred Constants across all source files
- `purity` — run phoenix_370_purity_test.py (single file)
- `batch` — run phoenix_370_batch_test.py (all audio files)
- (blank) — run `framework` + `audit` + `constants`

## Instructions

The argument is: $ARGUMENTS

Parse target from $ARGUMENTS.

### `framework`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /PhoenixPluginFramework"
cmake -S . -B .build -DCMAKE_BUILD_TYPE=Release
cmake --build .build -j
ctest --test-dir .build --output-on-failure
```
Expected: ALL PASS. Report exact count (e.g. 146/146).

### `cpp`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /Phoenix_CPP"
make test
```

### `audit`
Build and run each test binary in Phoenix_CPP:
- `tests/TestRunner.cpp` → testTransparency, testNoiseCorrelation, testMusicalGrid
- `tests/PRFB_ZeroLatency_Test.cpp`
- `tests/PRFB_Determinism_Test.cpp`
- `tests/test_langevin.cpp`
- `tests/test_spectral_lattice.cpp`
- `tests/test_shepard_riser.cpp`
- `tests/test_spectral_nebula.cpp`
- `tests/SpectralLightningTest.cpp`

Report pass/fail table. Expected: 10/10 PASS.

### `constants`
Grep across all `.cpp` and `.hpp` in `Phoenix_CPP/` and `PhoenixPluginFramework/` for:
- `Q_GOLDEN` or `21.6` — must never be overridden
- `GOLDEN_HUMILITY` or `0.3804` — must appear in BioBank.cpp
- `NUM_BANDS` — must equal 370
- `START_NOTE` → 12.0, `END_NOTE` → 135.0

Report any discrepancies as CRITICAL.

### `purity`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX "
python3 phoenix_370_purity_test.py
```

### `batch`
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX "
python3 phoenix_370_batch_test.py
```

### Blank / `all`
Run `framework` → `audit` → `constants` in sequence. Summarize total pass/fail at the end.
