# /audit-bugs — Code Audit → Worktodo

You are a Phoenix DSP code auditor. Your job: systematically audit a directory for bugs and
optimization opportunities, then append all findings to `Worktodo.md`. **Do not fix anything.**

**Language:** descriptions and notes in Russian. Code, identifiers, FIX lines — English only.

> ⚠️ CLAUDE.md has a startup ritual ("Прочитал. Сейчас в работе..."). **Ignore it for this session.**
> Your startup protocol is this file. Follow the steps below in order.

---

## Step 1 — Setup

Read these files:
```
/Users/macos/Documents/PHOENIXDSP/PHOENIX/framework/CRITICAL_RULES.md
/Users/macos/Documents/PHOENIXDSP/PHOENIX/core/include/phx/core/Common.hpp
/Users/macos/Documents/PHOENIXDSP/PHOENIX/Worktodo.md
```

From `Worktodo.md`, extract:
1. **Next free ID** — find the highest `BUG-XXX` and `PERF-XXX` numbers. Your IDs start from N+1.
2. **Already audited files** — skip any files listed in FIXED/WONTFIX tasks (don't re-audit).

Sacred constants (never flag as bugs, treat as correct):
- `NUM_BANDS = 370`, `Q_GOLDEN = 21.6f`, `GOLDEN_HUMILITY = 0.3804f`
- `START_NOTE = 12.0f`, `END_NOTE = 135.0f`, `BANDS_PER_NOTE = 3.0f`

---

## Step 2 — Enumerate files

Target directory from `$ARGUMENTS`. Example: `core/include/phx/`

List all `.cpp` and `.hpp` files in the target directory (recursively).
Read them **one by one** — do not skip, do not batch. For each file:
- Read the complete file
- Analyze it (Step 3)
- Collect findings before moving to the next file

---

## Step 3 — Audit checklist per file

For every file, check all of the following. Be thorough — do not just skim.

### 🔴 CRITICAL
- **Static local mutable state** — `static` variables with non-trivial state inside functions → data race in multi-instance
- **UB / Out-of-bounds** — array/container access without empty() check, index without bounds check
- **Division by zero** — denominators that can be 0.0 without guard
- **Null pointer deref** — raw pointers used without null check
- **Memory corruption** — buffer overflow, write past end

### 🟠 HIGH
- **Logic errors** — algorithm produces wrong result, missing inter-frame state, silent wrong output
- **Missing validation** — reads from external sources (file, network, param) without limit check
- **Sacred constant duplication** — `0.3804`, `21.6`, `370` hardcoded outside `Common.hpp`
- **Performance regression** — O(n²) loop where O(n log n) is trivially possible; transcendental functions (`sqrt`, `exp`, `log`, `pow`) called per-sample that could be amortized per-block or precomputed

### 🟡 MEDIUM
- **Precision issues** — phase accumulation without wrap at 2π, float precision degrading over time
- **Config loss on reset** — hardcoded literal in `reset()` instead of saved member config
- **Redundant computation** — same expensive value computed twice in the same scope
- **Fragile constants** — hardcoded magic sizes tied to NUM_BANDS without `std::max(...)` guard
- **noexcept violations** — function marked `noexcept` but calls functions that can throw (`std::sort` with lambda, `std::vector::push_back`, etc.)
- **Const violations** — method marked `const` but mutates state (directly or through non-mutable pointer)

### 🟢 LOW
- **Dead code** — unused `#include`, unreachable branch, dead variable
- **Variable shadowing** — local name hides a member with the same name
- **Magic constants** — unnamed numeric literals in critical paths (not trivially obvious values like 0, 1, 2)
- **Incomplete implementation** — `TODO`, hardcoded placeholder returning fixed value, stub logic
- **Misleading naming** — variable/function name contradicts what it actually contains/does

---

## Step 4 — Format each finding

```
[BUG-XXX] Filename.hpp:NN | Type | SEVERITY | OPEN
  Описание: что именно не так и почему это важно (на русском).
  FIX: Concrete action — what to change and where (English, ≤ 3 files).
```

- Use `[BUG-XXX]` for correctness/logic/safety issues
- Use `[PERF-XXX]` for pure performance issues
- Continue numbering from the highest existing ID in `Worktodo.md`
- One finding = one ID. Don't group unrelated issues into a single ID.
- `FIX:` must be actionable enough that a fresh agent can apply it without asking questions.

**Do not add findings for:**
- Code that is correct but could theoretically be "cleaner"
- Style preferences
- Things already listed in Worktodo.md

---

## Step 5 — Append to Worktodo.md

**Read** the full `Worktodo.md` first.

Then **Write** it back with a new SESSION block inserted **before** the `## Pending sessions` section.
Never overwrite the Pending sessions section or archived sessions.

New block format:
```markdown
---

## SESSION N — Аудит <directory> (YYYY-MM-DD)

---

### 🔴 CRITICAL

[findings here, or "*(нет)*" if none]

---

### 🟠 HIGH

[findings here, or "*(нет)*" if none]

---

### 🟡 MEDIUM

[findings here, or "*(нет)*" if none]

---

### 🟢 LOW

[findings here, or "*(нет)*" if none]

---
```

Also update the `## Pending sessions` section: mark the audited directory as `DONE ✅`.

---

## Step 6 — Summary report

Output to the user:

```
## Аудит <directory> завершён

Файлов проверено: N
Новых задач: N (CRITICAL: N | HIGH: N | MEDIUM: N | LOW: N)
Следующий свободный ID: BUG-XXX / PERF-XXX

[список только CRITICAL и HIGH кратко, если есть]

Запускай /fix для исправления.
```

**Stop here. Do not apply any fixes.**

---

## Quick reference

| Что | Где |
|-----|-----|
| Очередь задач | `Worktodo.md` (корень проекта) |
| Sacred constants | `core/include/phx/core/Common.hpp` |
| Правила audio thread | `framework/CRITICAL_RULES.md` |
| DSP источники | `core/src/`, `core/include/phx/`, `core/include/tem/` |
| Framework | `framework/include/phx/` |
