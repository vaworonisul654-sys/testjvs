# /new-plugin — Scaffold a new plugin in PhoenixPluginFramework

Generates a complete plugin package with a template-specific starting point.

## Usage
`/new-plugin <PluginName> [--tpl bare|spectral|dynamics|saturator|pitch]`

Examples:
- `/new-plugin MyGate` — bare stub (default)
- `/new-plugin SpectralMorph --tpl spectral` — 370-band BioEngine effect
- `/new-plugin GlueComp --tpl dynamics` — compressor/gate
- `/new-plugin TapeColor --tpl saturator` — drive/tone saturator
- `/new-plugin PitchBend --tpl pitch` — pitch shifter skeleton

## Templates

| Template   | Pre-wired DSP               | Parameters                             | UI components         |
|------------|-----------------------------|----------------------------------------|-----------------------|
| `bare`     | pass-through stub           | 1× Gain (placeholder)                  | 1 knob                |
| `spectral` | BioAmpNode (370-band IIR)   | Amount, Low Cut, High Cut, Mix, Output | phx-spectrum + 5 knobs|
| `dynamics` | inline feed-forward compressor | Threshold, Ratio, Knee, Attack, Release, Makeup, Mix | 7 knobs |
| `saturator`| TubeSaturation (per-sample) | Drive, Tone, Output, Mix               | 4 knobs               |
| `pitch`    | pitchRatio computed, stub   | Tune (st), Fine (ct), Formant, Mix     | 4 knobs               |

## Instructions

Arguments: $ARGUMENTS

Parse: PluginName (PascalCase), optional `--tpl <template>`.

### Paths

```bash
PHOENIX_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || echo '/Users/macos/Documents/PHOENIXDSP/PHOENIX')"
```

> ⚠️ The repo path may contain spaces. Always quote path variables in bash.

### Prerequisite check

Before running scaffold, verify the module exists in the registry (skip for `bare` template):
```bash
grep -i "<PluginName>" "$PHOENIX_ROOT/core/registry/modules.yaml"
```

If the module is NOT in the registry and the user intends to use a registered module, tell them:
> "Module not registered. Run `/new-module <ModuleName>` first to create the DSP module and register it."

For template-based plugins (spectral/dynamics/saturator/pitch) the registry check is optional —
these templates provide their own pre-wired DSP without requiring a registry entry.

### Step 1 — Run scaffold

Parse `--tpl` from `$ARGUMENTS`. Pass it through to the script:

```bash
cd "$PHOENIX_ROOT"
./framework/tools/new_plugin.sh $ARGUMENTS
```

**If scaffold exits with non-zero status — show the full output to the user and stop.**

This generates:
- `plugins/<Name>/<Name>Plugin.hpp` — PluginBase subclass (template-specific)
- `plugins/<Name>/<Name>Plugin.cpp` — empty CMake compilation unit
- `plugins/<Name>/ui/index.html` — WebView UI (template-specific controls)
- `plugins/<Name>/CHANGELOG.md` — auto-created by the script

The scaffold auto-inserts into `framework/CMakeLists.txt`. If auto-insert reports failure,
follow the manual instructions printed in the scaffold output.

### Step 2 — Register smoke test

After scaffold creates the plugin, manually add a smoke test entry to `framework/CMakeLists.txt`
inside the `# PHX_CODEGEN:SMOKE_BEGIN` / `# PHX_CODEGEN:SMOKE_END` block:

```cmake
phx_add_smoke_test(
    PLUGIN_NAME   <PluginName>
    PLUGIN_LIB    phx_plugins_<pluginname>
    PLUGIN_HEADER "<PluginName>Plugin.hpp"
    PLUGIN_DIR    "${CMAKE_CURRENT_SOURCE_DIR}/../plugins/<PluginName>"
)
```

Note: The codegen regex is known to fail after `phx_plugins_phoenix` — insert manually.
If the plugin uses a gate/expander pattern that legitimately silences input at default settings,
add to the plugin class: `static constexpr bool kExpectNonSilent = false;`

### Step 3 — Build & verify

```bash
cmake -S "$PHOENIX_ROOT/framework" --preset qa
cmake --build "$PHOENIX_ROOT/framework/build/qa" -j$(sysctl -n hw.logicalcpu)
"$PHOENIX_ROOT/framework/build/qa/phx_smoke_<PluginName>"
"$PHOENIX_ROOT/framework/build/qa/framework_qa"
```

Expected for smoke test: `✅ SMOKE PASS: <PluginName>Plugin`
Expected for framework_qa: `Failed: 0`. The passed count will be higher than before scaffold.
If either fails, show the failure output before continuing.

### Step 4 — Report

Show:
- Template used
- Generated files (list from scaffold output)
- Parameters registered (count + names from the HPP)
- Test result (pass count)
- Template-specific next steps (printed by the script)

For `dynamics` template: GlueCompressor is already wired — no stub warning.
For all other templates: `onProcess()` has TODO — warn user that DSP needs implementation.

### Architecture guards

Verify the generated plugin does NOT violate:
- Anti-aliasing / oversampling (IIR has no aliasing — never needed)
- Parameters below 20 Hz (filter bank starts there)
- FFT window / block latency params (we are sample-accurate IIR)
- `setLatencySamples()` calls (latency is always 0 — 1-sample pipeline)
- `new` / `delete` / `std::mutex` / `push_back` in `onProcess()` hot path
