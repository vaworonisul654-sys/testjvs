# /audit — Full DSP integrity audit

Verifies Sacred Constants, runs all tests, checks module spec compliance.
Use before any release, after major changes, or when something sounds wrong.

## Usage
`/audit [scope]`

**Scopes:**
- `constants` — Sacred Constants check only
- `tests` — all test suites only
- `modules` — spec compliance of DSP modules
- `codec` — PHOENIX_CODEC_2.0 integrity
- `framework` — PhoenixPluginFramework 146-test suite
- (blank) — full audit: constants + tests + modules

## Instructions

Arguments: $ARGUMENTS

Parse scope from $ARGUMENTS. Default: full audit.

---

### PHASE 1: Sacred Constants Audit

Scan `Phoenix_CPP/` and `PhoenixPluginFramework/` source files.

Verify exactly:
| Constant | Expected | Files to check |
|----------|----------|----------------|
| `Q_GOLDEN` | `21.6f` | BioBank.cpp, BioBand.hpp |
| `GOLDEN_HUMILITY` | `0.3804f` | BioBank.cpp (x2), BioBankSIMD.hpp, Biquad.hpp |
| `NUM_BANDS` | `370` | Common.hpp |
| `START_NOTE` | `12.0f` | TestRunner.cpp |
| `END_NOTE` | `135.0f` | TestRunner.cpp |

Any deviation → **CRITICAL** alert. Do not proceed until resolved.

---

### PHASE 2: Test Suite

Run and report:
```
BioEngine      → testTransparency (Max Diff = 0.0 expected)
BioEngine      → testNoiseCorrelation (L=1.0, R=1.0 expected)
BioEngine      → testMusicalGrid (Bands = 369 expected)
PRFB           → prfb_zero_latency_test (Latency = 0)
PRFB           → prfb_determinism_test (bitwise identical)
LangevinSat    → test_langevin (saturation + hysteresis)
SpectralLattice→ test_spectral_lattice (Freq→MIDI, Scale, Chord, Modes)
ShepardRiser   → test_shepard_riser (octave layers, modes, BPM sync)
SpectralNebula → test_spectral_nebula (entropy, stereo, 8 modes)
SpectralLightning → test_lightning (silence reject, strike, decay)
```

Target: 10/10 PASS.

---

### PHASE 3: Module Spec Compliance (if scope = modules or blank)

For each module in `include/phx/modules/`, verify:
- No FFT usage (grep `fft`, `FFT`, `DFT`)
- No `std::mutex` or blocking calls
- No heap allocation in `process()` (no `new`, `malloc`, `std::vector` construction)
- Float32 only (no `double` in hot path)

Report violations as MEDIUM or HIGH severity.

---

### PHASE 4: Codec Check (if scope = codec)

```bash
ls "/Users/myai/Documents/AI_Projects/PHOENIX /PHOENIX_CODEC_2.0/DECODERFULL/scripts/"
```

Run available validation scripts. Check:
- 120-band Bark layout still intact
- Bio-Spark weighting: `(f/1000)^0.7`
- Latency ≤ 1 sample

---

### Final Report

Output a single table:
```
Phase           | Status  | Notes
─────────────────────────────────────────
Constants       | ✅/❌   | ...
Tests           | X/10    | ...
Module Spec     | ✅/❌   | N violations
Codec           | ✅/❌   | ...
─────────────────────────────────────────
OVERALL         | PASS/FAIL
```

If OVERALL = FAIL → do not update any docs. Fix first.
