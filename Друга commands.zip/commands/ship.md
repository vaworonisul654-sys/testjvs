# /ship — Ship a Phoenix DSP plugin

Builds, signs, and packages a plugin into a macOS installer ready for distribution.

## Usage

```
/ship <PluginName> [--release] [--vst3-only] [--au2-only] [--skip-build]
/ship --list
```

## Modes

| Flag | Behaviour |
|------|-----------|
| *(default)* | Ad-hoc signing (`-`), output: `Products/dist/<Name>-<ver>-macOS-arm64.pkg` |
| `--release` | Developer ID + notarize + staple, output: `.dmg` |
| `--vst3-only` | Build & package VST3 only |
| `--au2-only` | Build & package AU2 only |
| `--skip-build` | Skip cmake, use existing binaries in `framework/build/` |

## Pipeline

```
cmake --preset vst3/au2
→ codesign --deep --force
→ pkgbuild (vst3 + au2)
→ productbuild (combined installer)
→ [--release] notarytool submit --wait + stapler staple
→ [--release] hdiutil create → .dmg
→ Products/dist/<Name>-<version>-macOS-arm64.{pkg|dmg}
```

## Prerequisites

- `pyyaml` (`pip install pyyaml`)
- `pkgbuild`, `productbuild`, `hdiutil` — macOS builtins
- `xcrun notarytool` — only for `--release`
- `.env` in repo root (optional):
  ```
  PHX_CODESIGN_IDENTITY=Developer ID Application: Your Name (TEAMID)
  PHX_APPLE_ID=your@email.com
  PHX_APPLE_TEAM_ID=XXXXXXXXXX
  PHX_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx
  ```

## Execution

```bash
python framework/tools/ship.py $ARGUMENTS
```

## Verification

```bash
# List available plugins
python framework/tools/ship.py --list

# Dev build (ad-hoc, PKG)
python framework/tools/ship.py MetaSaturator
# → ✓ Products/dist/MetaSaturator-1.0.1-macOS-arm64.pkg (N MB)

# Inspect PKG contents
pkgutil --payload-files Products/dist/MetaSaturator-1.0.1-macOS-arm64.pkg
# → ./Library/Audio/Plug-Ins/VST3/MetaSaturator.vst3/...
# → ./Library/Audio/Plug-Ins/Components/MetaSaturator.component/...
```
