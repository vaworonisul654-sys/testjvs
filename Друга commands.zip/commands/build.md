# /build — Build Phoenix DSP targets

Build one or more targets in the PHOENIX catalog.

## Usage
`/build [target]`

**Targets:**
- `framework` — PhoenixPluginFramework (Release)
- `cpp` — Phoenix_CPP (make)
- `vst3` — VST3 bundle only
- `debug` — Framework in Debug mode
- `all` — everything in sequence
- (blank) — same as `all`

## Instructions

The argument is: $ARGUMENTS

1. Parse the target from $ARGUMENTS (default: `all` if blank).

2. For target `framework` or `all`:
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /PhoenixPluginFramework"
cmake -S . -B .build -DCMAKE_BUILD_TYPE=Release
cmake --build .build -j
```

3. For target `cpp` or `all`:
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /Phoenix_CPP"
make
```

4. For target `vst3`:
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /PhoenixPluginFramework"
cmake -S . -B .build_vst3 -DCMAKE_BUILD_TYPE=Release -DBUILD_VST3=ON
cmake --build .build_vst3 -j --target VST3
```

5. For target `debug`:
```bash
cd "/Users/myai/Documents/AI_Projects/PHOENIX /PhoenixPluginFramework"
cmake -S . -B .buildDebug -DCMAKE_BUILD_TYPE=Debug
cmake --build .buildDebug -j
```

6. After build: report success/failure, show binary paths, note any warnings.
7. If errors: diagnose, propose fix. Do NOT silently ignore.
